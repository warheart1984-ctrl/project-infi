"use client";

import { useEffect, useMemo, useState } from "react";
import { JournalEntry, MythicReading } from "@/lib/types";

const defaultReading: MythicReading = {
  state: "transforming",
  dominantArchetype: "hero",
  opposingArchetype: "shadow",
  trial: "Reaction vs control",
  nextAction: "Pause for 10 seconds before acting when anger rises.",
  meaning: "You are replacing reaction with deliberate choice.",
  risk: "Ignoring the pause can reactivate regret loops."
};

const STORAGE_KEY = "mythic-ai-entries";

export function JournalForm() {
  const [input, setInput] = useState(
    "Right now I am in the state of awakening and control because I created a new rule instead of staying trapped in reaction."
  );
  const [reading, setReading] = useState<MythicReading>(defaultReading);
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as JournalEntry[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        setEntries(parsed);
        setReading(parsed[0].reading);
      }
    } catch {
      // ignore local parsing errors
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  }, [entries]);

  const streak = useMemo(() => Math.max(1, entries.length), [entries.length]);

  async function submitEntry(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/reading", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error ?? "Failed to generate reading.");
      }

      const nextReading = data.reading as MythicReading;
      setReading(nextReading);
      setEntries((prev) => [
        {
          input,
          createdAt: new Date().toISOString(),
          reading: nextReading
        },
        ...prev
      ]);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong.";
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  function clearEntries() {
    setEntries([]);
    setReading(defaultReading);
    window.localStorage.removeItem(STORAGE_KEY);
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      <div className="xl:col-span-2 space-y-6">
        <div className="rounded-3xl border border-zinc-800 bg-zinc-900/70 p-6 shadow-lg backdrop-blur">
          <h2 className="text-2xl font-semibold">Journal Input</h2>
          <p className="text-zinc-400 mt-1">The engine starts with one honest sentence.</p>

          <form onSubmit={submitEntry} className="mt-4 space-y-4">
            <textarea
              value={input}
              onChange={(event) => setInput(event.target.value)}
              rows={6}
              className="w-full rounded-2xl border border-zinc-800 bg-zinc-950 p-4 text-zinc-100 outline-none focus:border-zinc-600"
              placeholder="Write one honest sentence about your state..."
            />

            <div className="flex items-center gap-3 flex-wrap">
              <button
                type="submit"
                disabled={loading}
                className="rounded-2xl border border-zinc-700 px-5 py-3 font-medium transition hover:border-zinc-500 disabled:opacity-50"
              >
                {loading ? "Reading..." : "Generate Reading"}
              </button>
              <button
                type="button"
                onClick={clearEntries}
                className="rounded-2xl border border-zinc-800 px-5 py-3 font-medium transition hover:border-zinc-600"
              >
                Clear History
              </button>
              {error ? <span className="text-sm text-red-400">{error}</span> : null}
            </div>
          </form>
        </div>

        <div className="rounded-3xl border border-zinc-800 bg-zinc-900/70 p-6 shadow-lg backdrop-blur">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <h2 className="text-2xl font-semibold">Current Reading</h2>
            <div className="rounded-full border border-zinc-700 px-3 py-1 text-sm capitalize">
              Streak: {streak} day
            </div>
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
              <div className="text-sm text-zinc-400">State</div>
              <div className="mt-2 text-lg font-medium capitalize">{reading.state}</div>
            </div>
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
              <div className="text-sm text-zinc-400">Dominant Archetype</div>
              <div className="mt-2 text-lg font-medium capitalize">{reading.dominantArchetype}</div>
            </div>
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
              <div className="text-sm text-zinc-400">Trial</div>
              <div className="mt-2 text-lg font-medium">{reading.trial}</div>
            </div>
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
              <div className="text-sm text-zinc-400">Next Action</div>
              <div className="mt-2 text-lg font-medium">{reading.nextAction}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-zinc-800 bg-zinc-900/70 p-6 shadow-lg backdrop-blur">
        <h2 className="text-2xl font-semibold">Recent Entries</h2>
        <div className="mt-4 space-y-3">
          {entries.length === 0 ? (
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4 text-zinc-400">
              No entries yet. Generate your first reading.
            </div>
          ) : (
            entries.slice(0, 6).map((entry) => (
              <div key={entry.createdAt} className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4">
                <div className="text-sm text-zinc-400 capitalize">{entry.reading.state}</div>
                <div className="mt-2 text-sm text-zinc-300">{entry.input}</div>
                <div className="mt-3 text-xs text-zinc-500">
                  {new Date(entry.createdAt).toLocaleString()}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
