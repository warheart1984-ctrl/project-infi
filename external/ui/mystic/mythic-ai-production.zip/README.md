# Mythic AI

A production-style Next.js starter for a mythic reflection dashboard.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Included

- Next.js App Router
- Tailwind styling
- Mythic engine
- API route for readings
- Dashboard UI
- Journal input and local persistence
- Recent entries panel
