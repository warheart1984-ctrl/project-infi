export default function Home() {
  return <div>Mythic AI Running</div>;
}