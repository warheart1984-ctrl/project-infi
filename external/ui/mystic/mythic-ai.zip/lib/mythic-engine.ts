export function mythicEngine(input: string) {
  return {
    state: "transforming",
    trial: "Reaction vs control",
    nextAction: "Pause for 10 seconds before acting"
  };
}