import { NextResponse } from 'next/server';
import { z } from 'zod';
import { runAAIS } from '@/lib/core/orchestrator';

const chatMessageSchema = z.object({
  id: z.string(),
  role: z.enum(['system', 'user', 'assistant']),
  content: z.string(),
  createdAt: z.string(),
});

const chatRequestSchema = z.object({
  messages: z.array(chatMessageSchema).min(1),
});

export async function POST(request: Request) {
  try {
    const json = await request.json();
    const parsed = chatRequestSchema.safeParse(json);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid chat payload', details: parsed.error.flatten() },
        { status: 400 },
      );
    }

    const output = await runAAIS({ messages: parsed.data.messages });

    return NextResponse.json({ output });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown server error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
