import OpenAI from 'openai';
import { AAIS_SYSTEM_PROMPT } from '@/lib/core/prompts';
import { selectModel } from '@/lib/core/router';
import { buildShortTermMemory } from '@/lib/memory/short-term';
import { retrieveLongTermMemory } from '@/lib/memory/long-term';
import type { ChatMessage } from '@/lib/types/chat';

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface RunAAISInput {
  messages: ChatMessage[];
}

export async function runAAIS({ messages }: RunAAISInput): Promise<string> {
  const shortTerm = buildShortTermMemory(messages);
  const latestUserMessage = [...messages].reverse().find((message) => message.role === 'user');
  const longTerm = latestUserMessage
    ? await retrieveLongTermMemory(latestUserMessage.content)
    : [];

  const memoryBlock = [
    `Short-term summary:\n${shortTerm.conversationSummary}`,
    `Relevant long-term memory:\n${longTerm.map((entry) => `- (${entry.kind}) ${entry.content}`).join('\n') || 'None'}`,
  ].join('\n\n');

  const response = await client.responses.create({
    model: selectModel(),
    input: [
      {
        role: 'system',
        content: [
          { type: 'input_text', text: AAIS_SYSTEM_PROMPT },
          { type: 'input_text', text: memoryBlock },
        ],
      },
      ...shortTerm.recentMessages.map((message) => ({
        role: message.role,
        content: [{ type: 'input_text' as const, text: message.content }],
      })),
    ],
  });

  return response.output_text || 'AAIS did not return text.';
}
