export interface RetrievedMemory {
  id: string;
  kind: 'profile' | 'preference' | 'project' | 'episode';
  content: string;
  score: number;
}

export async function retrieveLongTermMemory(_input: string): Promise<RetrievedMemory[]> {
  // Placeholder for pgvector / Qdrant / embeddings retrieval.
  return [
    {
      id: 'seed-memory-1',
      kind: 'project',
      content: 'User is building AAIS, an Adaptive Autonomous Intelligence System.',
      score: 0.95,
    },
  ];
}
