import { z } from 'zod';

export interface ToolContext {
  userId?: string;
}

export interface ToolDefinition<TInput = unknown, TResult = unknown> {
  name: string;
  description: string;
  inputSchema: z.ZodType<TInput>;
  execute: (input: TInput, context: ToolContext) => Promise<TResult>;
}

const echoTool: ToolDefinition<{ text: string }, { echoed: string }> = {
  name: 'echo',
  description: 'Echoes text for early tool wiring tests.',
  inputSchema: z.object({
    text: z.string().min(1),
  }),
  async execute(input) {
    return { echoed: input.text };
  },
};

export const toolRegistry = {
  echo: echoTool,
};

export type ToolName = keyof typeof toolRegistry;
