'use client';

import { useState } from 'react';
import type { ChatMessage } from '@/lib/types/chat';

function makeMessage(role: ChatMessage['role'], content: string): ChatMessage {
  return {
    id: crypto.randomUUID(),
    role,
    content,
    createdAt: new Date().toISOString(),
  };
}

export function ChatClient() {
  const [input, setInput] = useState('Help me design AAIS version 1.');
  const [messages, setMessages] = useState<ChatMessage[]>([
    makeMessage('assistant', 'AAIS online. Give me a goal and I will help structure the build.'),
  ]);
  const [loading, setLoading] = useState(false);

  async function submit() {
    const trimmed = input.trim();
    if (!trimmed || loading) return;

    const userMessage = makeMessage('user', trimmed);
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: nextMessages }),
      });

      const data = (await response.json()) as { output?: string; error?: string };

      if (!response.ok) {
        throw new Error(data.error || 'Request failed');
      }

      setMessages((current) => [...current, makeMessage('assistant', data.output || 'No output.')]);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown client error';
      setMessages((current) => [...current, makeMessage('assistant', `Error: ${message}`)]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ maxWidth: 980, margin: '0 auto', padding: 24 }}>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ margin: 0, fontSize: 34 }}>AAIS Starter</h1>
        <p style={{ color: 'var(--muted)', marginTop: 8 }}>
          Version 1 foundation: chat UI, API route, orchestrator, short-term memory, long-term memory stub, and tool registry skeleton.
        </p>
      </div>

      <div
        style={{
          border: '1px solid var(--border)',
          borderRadius: 16,
          background: 'var(--panel)',
          padding: 16,
          minHeight: 420,
          display: 'flex',
          flexDirection: 'column',
          gap: 12,
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, flex: 1 }}>
          {messages.map((message) => (
            <div
              key={message.id}
              style={{
                alignSelf: message.role === 'user' ? 'flex-end' : 'flex-start',
                maxWidth: '80%',
                background: message.role === 'user' ? 'var(--panel-2)' : '#10162d',
                border: '1px solid var(--border)',
                borderRadius: 14,
                padding: '12px 14px',
                whiteSpace: 'pre-wrap',
                lineHeight: 1.45,
              }}
            >
              <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 6 }}>{message.role.toUpperCase()}</div>
              {message.content}
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gap: 10 }}>
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            rows={5}
            placeholder="Tell AAIS what to build..."
            style={{
              width: '100%',
              resize: 'vertical',
              borderRadius: 12,
              border: '1px solid var(--border)',
              background: '#0d1430',
              color: 'var(--text)',
              padding: 12,
            }}
          />
          <button
            onClick={submit}
            disabled={loading}
            style={{
              justifySelf: 'start',
              padding: '10px 16px',
              borderRadius: 12,
              border: '1px solid var(--border)',
              background: 'var(--accent)',
              color: '#061027',
              fontWeight: 700,
              cursor: loading ? 'not-allowed' : 'pointer',
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? 'AAIS thinking...' : 'Send'}
          </button>
        </div>
      </div>
    </main>
  );
}
