# AAIS Starter

A minimal Next.js + TypeScript foundation for your **Adaptive Autonomous Intelligence System**.

## Included

- Chat UI
- `/api/chat` backend route
- Core AAIS orchestrator
- Short-term memory builder
- Long-term memory retrieval stub
- Tool registry skeleton
- Environment template

## Quick start

```bash
npm install
cp .env.example .env.local
# add your OPENAI_API_KEY to .env.local
npm run dev
```

Open `http://localhost:3000`

## Current architecture

```txt
src/
  app/
    api/chat/route.ts
    layout.tsx
    page.tsx
  components/
    ChatClient.tsx
  lib/
    core/
      orchestrator.ts
      prompts.ts
      router.ts
    memory/
      short-term.ts
      long-term.ts
    tools/
      registry.ts
    types/
      chat.ts
```

## Next moves

1. Add streaming responses in `/api/chat`
2. Store conversations in Postgres
3. Replace `long-term.ts` stub with embeddings retrieval
4. Add planner and executor modules
5. Add permissioned tools
